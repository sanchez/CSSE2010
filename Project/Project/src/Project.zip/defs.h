#pragma once

#define F_CPU 8000000L